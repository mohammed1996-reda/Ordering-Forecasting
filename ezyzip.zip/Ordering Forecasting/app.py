#import libraries
##################################################
##################################################
##################################################
############# Created by Dr. Mohamed R. Shoaib
############# Created at: 25/05/2022
############# Shgardi Company
##################################################
##################################################
##################################################
import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle
from gevent.pywsgi import WSGIServer
import pandas as pd
#Initialize the flask App
from flask import Flask, request, render_template, redirect, url_for, flash, send_file, make_response
import pandas as pd
import io
app = Flask(__name__)
from sklearn.preprocessing import OrdinalEncoder
from werkzeug.utils import secure_filename
ord_enc = OrdinalEncoder()
#default page of our web-app
@app.route('/')
def home():
    return render_template('index_1.html')
#####################################################
app.secret_key = '123456'

@app.route('/', methods=['GET','POST'])
def upload():
    if request.method=='POST':
        file=request.files['file']
        file_1 = request.files['file_1']
        filename = secure_filename(file_1.filename)
        if file.filename != '':
            df = pd.read_excel(file)
            model = pickle.load(open(filename, 'rb'))
            new_data_1 = df[['Date', 'Zone']]
            data="hello"
            df['zone_code'] = ord_enc.fit_transform(df[['Zone']])
            df['TIMESTAMP'] = pd.to_datetime(df['Date'])
            df['year'] = pd.DatetimeIndex(df['TIMESTAMP']).year
            df['month'] = pd.DatetimeIndex(df['TIMESTAMP']).month
            df['day'] = pd.DatetimeIndex(df['TIMESTAMP']).day
            df['hour'] = pd.DatetimeIndex(df['TIMESTAMP']).hour
            new_data = df.drop(['Date', 'Zone', 'TIMESTAMP'], axis=1)
            prediction = model.predict(new_data)
            output = prediction.round()
            new_data_1['order_new'] = output
            # Creating output and writer (pandas excel writer)
            out = io.BytesIO()
            writer = pd.ExcelWriter(out, engine='xlsxwriter')
            # Export data frame to excel
            new_data_1.to_excel(excel_writer=writer, index=False, sheet_name='Sheet1')
            writer.save()
            writer.close()
            # Flask create response
            r = make_response(out.getvalue())
            # Defining correct excel headers
            r.headers["Content-Disposition"] = "attachment; filename=Prediction Output.xlsx"
            r.headers["Content-type"] = "application/x-xls"
            # Finally return response
            return r

if __name__ == "__main__":
    app.run(debug=True)
